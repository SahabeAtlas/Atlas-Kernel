[org 0x7c00]
[bits 16]

boot_start:
        mov [boot_drive], dl
        
        mov ax, 0
        mov ds, ax
        mov es, ax

        mov bx, 0x1000
        mov ah, 0x02
        mov al, 15
        mov ch, 0
        mov dh, 0
        mov cl, 2
        mov dl, [boot_drive]
        int 0x13
        
        jmp 0x0000:0x1000

boot_drive: db 0

times 510 - ( $ - $$ ) db 0
dw 0xaa55
