[org 0x7c00]
mov ah, 0x0e
mov al, 'A'
int 0x10
mov al, 'T'
int 0x10
mov al, 'L'
int 0x10
mov al, 'A'
int 0x10
mov al, 'S'
int 0x10
mov al, ' '
int 0x10
mov al, 'K'
int 0x10
mov al, 'E'
int 0x10
mov al, 'R'
int 0x10
mov al, 'N'
int 0x10
mov al, 'E'
int 0x10
mov al, 'L'
int 0x10
mov al, ' '
int 0x10
mov al, '0'
int 0x10
mov al, '.'
int 0x10
mov al, '0'
int 0x10
mov al, '1'
int 0x10
jmp $
times 510 - ( $ - $$ ) db 0
dw 0xAA55
