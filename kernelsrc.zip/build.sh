sudo apt install nano nasm
echo "1:all dependencies installed"
sudo rm boot.img
nasm -f bin boot.asm -o boot.img
echo "2:image built"
echo "3:this is a raw image that only boots in legacy bios systems or csm mode without secure boot!"
