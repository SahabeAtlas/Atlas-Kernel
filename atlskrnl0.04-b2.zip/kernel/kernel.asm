[org 0x1000]
[bits 16]

initmsgcaller:
        mov ax, 0
        mov ds, ax
        mov es, ax
        mov di, 0x2000
        mov si, initmsg
        call printstr
        call newline
        jmp nameask

reset:
	mov ax, 0
	mov ds, ax
	mov es, ax
	mov di, 0x2000
	jmp input

input:
	mov ah, 0x00
	int 0x16
	cmp al, 0x0D
	je inputfinish
	cmp ah, 0x1C
	je inputfinish
	cmp al, 0x08
	je backspace
	cmp ah, 0x0E
	je backspace
	mov ah, 0x0E
	je backspace
	int 0x10
	mov [di], al
	inc di
	jmp input

inputfinish:
    mov byte [di], 0

helpcmd:
        cmp byte [0x2000], 'h'
        jne vercmd
        cmp byte [0x2001], 'l'
        jne failprnt
        cmp byte [0x2002], 'p'
        jne failprnt
        cmp byte [0x2003], 0
        jne failprnt
        jmp helpprnt

vercmd:
	cmp byte [0x2000], 'v'
	jne clrcmd
	cmp byte [0x2001], 'e'
	jne failprnt
	cmp byte [0x2002], 'r'
	jne failprnt
	cmp byte [0x2003], 0
	jne failprnt
	jmp verprnt

printstr:
	push ax

.textloop:
	mov al, [si]
	cmp al, 0
	je printOK
	mov ah, 0x0e
	int 0x10
	inc si
	jmp .textloop

printOK:
	pop ax
	ret

verprnt:
	call newline
	mov si, version
	call printstr
	mov si, atcltover
	call printstr
	mov si, guiprompt
	call printstr
	mov si, fsprompt
	call printstr
	call newline
	jmp promptstart

failprnt:
	call newline
	mov si, fail
	call printstr
	call newline
	jmp promptstart

helpprnt:
	call newline
	mov si, help
	call printstr
	call newline
	jmp promptstart

newline:
	push ax
	mov ah, 0x0E
        mov al, 0x0A
        int 0x10
	mov al, 0x0D
	int 0x10
	pop ax
	ret

backspace:
	cmp di, 0x3000
	je .stoperase
	cmp di, 0x2000
	je .stoperase
	dec di
	mov ah, 0x0E
	mov al, 0x08
	int 0x10
	mov al, ' '
	int 0x10
	mov al, 0x08
	int 0x10
	jmp input

.stoperase:
	cmp di, 0x3000
	jae nameask.loop
	jmp input

clrcmd:
	cmp byte [0x2000], 'c'
	jne rbcmd
	cmp byte [0x2001], 'l'
	jne failprnt
	cmp byte [0x2002], 'r'
        jne failprnt
        cmp byte [0x2003], 0
        jne failprnt
        jmp clrprnt

clrprnt:
        mov ah, 0x00
        mov al, 0x03
        int 0x10
        jmp promptstart

rbcmd:
	cmp byte [0x2000], 'r'
	jne mfordcmd
	cmp byte [0x2001], 'b'
	jne failprnt
	cmp byte [0x2002], 0
	jne failprnt
        mov ah, 0x00
        mov al, 0x03
        int 0x10
	jmp reboot

reboot:
	int 0x19

nameask:
	mov di, 0x3000
	mov si, nameaskmsg
        call printstr

.loop:
        mov ah, 0x00
        int 0x16
        cmp al, 0x0D
        je .userok
        cmp ah, 0x1C
        je .userok
	cmp al, 0x08
	je backspace
	cmp ah, 0x0E
	je backspace
        mov ah, 0x0E
        int 0x10
        mov [di], al
        inc di
        jmp .loop

.userok:
	mov byte [di], 0
	call newline
	jmp promptstart

promptstart:
        mov di, 0x2000
	mov si, 0x3000
	call printstr
	mov si, prompt
	call printstr
	jmp input

mfordprnt:
        call newline
        mov si, mford
        call printstr
        call newline
        jmp promptstart

mfordcmd:
        cmp byte [0x2000], 'm'
        jne guicmd
        cmp byte [0x2001], '4'
        jne failprnt
        cmp byte [0x2002], 'd'
        jne failprnt
	cmp byte [0x2003], 0
	jne failprnt
        jmp mfordprnt

guicmd:
        cmp byte [0x2000], 'g'
	jne failprnt
        cmp byte [0x2001], 'u'
	jne failprnt
        cmp byte [0x2002], 'i'
	jne failprnt
        cmp byte [0x2003], 0
	jne failprnt
        jmp draw_desktop
        jmp promptstart


fat12_load_file:
        push cx
        push dx
        push di
        push si

        mov [target_buffer], bx
        mov [search_name], si

        mov ax, 19              
        mov bx, 0x8000          
        call read_sector_fat12

        mov bx, 0x8000          
        mov cx, 224             

.entry_loop:
        cmp byte [bx], 0
        je .file_not_found      
        cmp byte [bx], 0xE5
        je .next_entry          

        mov di, bx
        mov si, [search_name]
        push cx
        mov cx, 8               
        repe cmpsb
        pop cx
        jne .next_entry         

        cmp byte [bx + 8], 'F'
	jne .next_entry
        cmp byte [bx + 9], 'I'
	jne .next_entry
        cmp byte [bx + 10], 'L'
	jne .next_entry
	cmp byte [bx + 11], 'E'
	jne .next_entry
        jmp .file_found         

.next_entry:
        add bx, 32              
        loop .entry_loop
        jmp .file_not_found

.file_found:
        mov ax, [bx + 26]       
        sub ax, 2
        add ax, 33              

        mov bx, [target_buffer] 
        mov ah, 0x02
        mov al, 1               
        mov ch, 0
        mov dh, 0
        mov cl, al              
        mov dl, 0x00            
        int 0x13

        mov ax, 1               
        jmp .done

.file_not_found:
        mov ax, 0               

.done:
        pop si
        pop di
        pop dx
        pop cx
        ret

target_buffer: dw 0
search_name:   dw 0

read_sector_fat12:
        mov ah, 0x02
        mov al, 1
        mov ch, 0
        mov dh, 0
        mov cl, al
        mov dl, 0x00
        int 0x13
        ret


draw_desktop:
        push ax
        push bx
        push cx
        push dx

        mov byte [current_selection], 0
        mov byte [has_output], 0

.redraw_all:
        mov ax, 0x0003          
        int 0x10                

        mov dh, 1               
        mov dl, 43              
        call move_cursor
        
        mov al, 201             
        call print_blue_char

        mov cx, 34              
.top_line:
        push cx
        mov al, 205             
        call print_blue_char
        pop cx
        loop .top_line

        mov al, 187             
        call print_blue_char

        mov cx, 8               
        mov dh, 2
.body_loop:
        push cx
        mov dl, 43
        call move_cursor
        mov al, 186             
        call print_blue_char

        mov cx, 34
.space_loop:
        push cx
        mov al, ' '             
        call print_blue_char
        pop cx
        loop .space_loop

        mov al, 186             
        call print_blue_char
        
        inc dh
        pop cx
        loop near .body_loop

        mov dl, 43
        call move_cursor
        mov al, 200             
        call print_blue_char

        mov cx, 34
.bottom_line:
        push cx
        mov al, 205             
        call print_blue_char
        pop cx
        loop .bottom_line

        mov al, 188             
        call print_blue_char

        mov dh, 24
        mov dl, 2
        call move_cursor

        mov cx, 5
        mov si, app_list
        mov bl, 0

.draw_panel_loop:
        push bx
        push si
        
        cmp bl, [current_selection]
        je short .draw_selected
        
        mov al, ' '
        call print_normal_char
        mov al, ' '
        call print_normal_char
        jmp short .print_app_name

.draw_selected:
        mov al, '-'
        call print_normal_char
        mov al, '>'
        call print_normal_char

.print_app_name:
        mov si, [si]            
        call print_app_box
        
        mov al, ' '
        call print_normal_char
        mov al, ' '
        call print_normal_char

        pop si
        add si, 2
        pop bx
        inc bl
        loop near .draw_panel_loop

        cmp byte [has_output], 0
        je short .input_loop
        
        cmp byte [has_output], 1
        je short .print_ver_flow
        
        cmp byte [has_output], 2
        je short .print_hlp_flow
        
        jmp short .input_loop

.print_ver_flow:
        mov dh, 2
        mov dl, 45
        mov word [output_ptr], version
        call print_cached_output
        
        mov word [output_ptr], atcltover
        call print_cached_output

        mov word [output_ptr], txt_gui_proto
        call print_cached_output
        
        mov word [output_ptr], fsprompt
        call print_cached_output
        
        mov byte [has_output], 0
        jmp short .input_loop

.print_hlp_flow:
        mov dh, 2
        mov dl, 45
        mov word [output_ptr], help
        call print_cached_output
        
        mov byte [has_output], 0

.input_loop:
        mov ah, 0x00
        int 0x16

        cmp al, 13
        je near .submit_app

        cmp ah, 0x4B
        je short .move_left

        cmp ah, 0x4D
        je short .move_right
        
        jmp short .input_loop

.move_left:
        cmp byte [current_selection], 0
        je short .input_loop
        dec byte [current_selection]
        jmp near .redraw_all

.move_right:
        cmp byte [current_selection], 4
        je short .input_loop
        inc byte [current_selection]
        jmp near .redraw_all

.submit_app:
        mov al, [current_selection]
        cmp al, 0
        je near .exec_ver
        cmp al, 1
        je near .exec_hlp
        cmp al, 2
        je near .exec_clr
        cmp al, 3
        je near .exec_rb
        cmp al, 4
        je near .exec_gui
        jmp short .input_loop

.exec_ver:
        mov byte [has_output], 1
        jmp near .redraw_all

.exec_hlp:
        mov byte [has_output], 2
        jmp near .redraw_all

.exec_clr:
        mov byte [has_output], 0
        jmp near .redraw_all

.exec_rb:
        mov ax, 0
        mov ds, ax
        mov es, ax
        pop dx
        pop cx
        pop bx
        pop ax
        jmp rbcmd

.exec_gui:
        jmp near .redraw_all

move_cursor:
        mov ah, 0x02
        mov bh, 0               
        int 0x10
        ret

print_blue_char:
        mov ah, 0x0E
        mov bl, 0x1F            
        int 0x10
        ret

print_normal_char:
        mov ah, 0x0E
        mov bl, 0x07            
        int 0x10
        ret

print_app_box:
        push si
        
        mov al, '['
        call print_normal_char
        
        mov al, ' '
        call print_normal_char

.str_loop:
        lodsb
        cmp al, 0
        je short .str_done
        call print_normal_char
        jmp short .str_loop

.str_done:
        mov al, ' '
        call print_normal_char
        
        mov al, ']'
        call print_normal_char
        
        pop si
        ret

print_cached_output:
        mov si, [output_ptr]
.char_loop:
        lodsb
        cmp al, 0
        je short .done
        cmp al, 0x0A            
        je short .newline
        cmp al, 0x0D            
        je short .char_loop
        call move_cursor
        call print_blue_char
        inc dl
        jmp short .char_loop
.newline:
        inc dh
        mov dl, 45
        jmp short .char_loop
.done:
        inc dh
        mov dl, 45
        ret

align 2
current_selection: db 0
has_output:        db 0
output_ptr:        dw 0

txt_ver: db "VER", 0
txt_hlp: db "HLP", 0
txt_clr: db "CLR", 0
txt_rb:  db "RB", 0
txt_gui: db "GUI", 0

txt_gui_proto: db "ATLAS GUI SERVICE PROTOTYPE", 0x0A, 0x0D, 0

align 2
app_list:
        dw txt_ver
        dw txt_hlp
        dw txt_clr
        dw txt_rb
        dw txt_gui

nameaskmsg:     db "Enter username:", 0
prompt:   db "@kernel: ", 0
version:  db "ATLAS KERNEL v0.04-build2", 0x0A, 0x0D, 0
fail:     db "Command Not Found(write hlp for help)", 0x0A, 0x0D, 0
help:     db "ver, hlp, clr, rb, gui", 0x0A, 0x0D, 0
atcltover:     db "ATCLTO(atlas command line tools) 0.1 with GUI", 0x0A, 0x0D, 0
guiprompt:     db "ATLAS GUI SERVICE v0.0.1", 0x0A, 0x0D, 0
fsprompt:     db "extra info for developers: FAT12 FS for testing", 0x0A, 0x0D, 0
initmsg:     db "Kernel OK!", 0x0A, 0x0D, 0
mford:     db "hello developer, thx for using atlas kernel!", 0x0A, 0x0D, 0
;write m4d for a suprise
