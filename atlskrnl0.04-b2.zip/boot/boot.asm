[org 0x7C00]

jmp short boot_start
nop

db "computer"
dw 512
db 1
dw 1
db 2
dw 224
dw 2880
db 0xF0
dw 9
dw 18
dw 2
dd 0
dd 0

db 0
db 0
db 0x29
dd 0x12345678
db "ATLS KRNL  "
db "FAT12   "

boot_start:
        mov [boot_drive], dl

        mov ax, 0
        mov ds, ax
        mov es, ax

        mov bx, 0x1000
        mov ah, 0x02
        mov al, 15
        mov ch, 0
        mov dh, 0
        mov cl, 2
        mov dl, [boot_drive]
        int 0x13

        jmp 0x0000:0x1000

boot_drive: db 0

times 510 - ( $ - $$ ) db 0
dw 0xaa55
