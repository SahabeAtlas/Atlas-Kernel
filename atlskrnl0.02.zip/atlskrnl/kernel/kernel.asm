[org 0x1000]
[bits 16]

mov ah, 0x0e
mov al, 'O'
int 0x10

mov al, 'K'
int 0x10

mov al, 0x0A
int 0x10
mov al, 0x0D
int 0x10
call promptstart
jmp reset

promptstart:
	mov si, prompt
	call printstr
reset:
	mov ax, 0
	mov ds, ax
	mov es, ax
	mov di, 0x2000
	jmp input

input:
	mov ah, 0x00
	int 0x16

	cmp al, 'q'
	je inputfinish

	mov ah, 0x0E
	int 0x10

	mov [di], al
	inc di
	jmp input

inputfinish:
    mov byte [di], 0

vercmd:
	cmp byte [0x2000], 'v'
	jne fail
	cmp byte [0x2001], 'e'
	jne fail
	cmp byte [0x2002], 'r'
	jne fail
	cmp byte [0x2003], 0
	jne failprnt
	jmp verprnt

debug:
	mov ah, 0x00
	int 0x16
	mov ah, 0x0e
	int 0x10
	jmp input

printstr:
	push ax
.textloop
	mov al, [si]
	cmp al, 0
	je printOK

	mov ah, 0x0e
	int 0x10
	inc si
	jmp .textloop

printOK:
	pop ax
	ret

verprnt:
	call newline
	mov si, version
	call printstr
	call newline
	jmp promptstart

failprnt:
	call newline
	mov si, fail
	call printstr
	call newline
	jmp promptstart

newline:
	push ax
	mov ah, 0x0E
        mov al, 0x0A
        int 0x10
	mov al, 0x0D
	int 0x10
	pop ax
	ret
prompt:   db "kerneluser: ", 0
version:  db "ATLAS KERNEL v0.02", 0x0A, 0x0D, 0
fail:     db "error", 0x0A, 0x0D, 0
