[org 0x1000]
[bits 16]

initmsgcaller:
        mov ax, 0
        mov ds, ax
        mov es, ax
        mov di, 0x2000
        mov si, initmsg
        call printstr
        call newline
        jmp nameask

reset:
	mov ax, 0
	mov ds, ax
	mov es, ax
	mov di, 0x2000
	jmp input

input:
	mov ah, 0x00
	int 0x16
	cmp al, 0x0D
	je inputfinish
	cmp ah, 0x1C
	je inputfinish
	cmp al, 0x08
	je backspace
	cmp ah, 0x0E
	je backspace
	mov ah, 0x0E
	je backspace
	int 0x10
	mov [di], al
	inc di
	jmp input

inputfinish:
    mov byte [di], 0

helpcmd:
        cmp byte [0x2000], 'h'
        jne vercmd
        cmp byte [0x2001], 'l'
        jne failprnt
        cmp byte [0x2002], 'p'
        jne failprnt
        cmp byte [0x2003], 0
        jne failprnt
        jmp helpprnt

vercmd:
	cmp byte [0x2000], 'v'
	jne clrcmd
	cmp byte [0x2001], 'e'
	jne failprnt
	cmp byte [0x2002], 'r'
	jne failprnt
	cmp byte [0x2003], 0
	jne failprnt
	jmp verprnt

printstr:
	push ax

.textloop
	mov al, [si]
	cmp al, 0
	je printOK
	mov ah, 0x0e
	int 0x10
	inc si
	jmp .textloop

printOK:
	pop ax
	ret

verprnt:
	call newline
	mov si, version
	call printstr
	mov si, atcltover
	call printstr
	call newline
	jmp promptstart

failprnt:
	call newline
	mov si, fail
	call printstr
	call newline
	jmp promptstart

helpprnt:
	call newline
	mov si, help
	call printstr
	call newline
	jmp promptstart

newline:
	push ax
	mov ah, 0x0E
        mov al, 0x0A
        int 0x10
	mov al, 0x0D
	int 0x10
	pop ax
	ret

backspace:
	cmp di, 0x3000
	je .stoperase
	cmp di, 0x2000
	je .stoperase
	dec di
	mov ah, 0x0E
	mov al, 0x08
	int 0x10
	mov al, ' '
	int 0x10
	mov al, 0x08
	int 0x10
	jmp input

.stoperase:
	cmp di, 0x3000
	jae nameask.loop
	jmp input

clrcmd:
	cmp byte [0x2000], 'c'
	jne rbcmd
	cmp byte [0x2001], 'l'
	jne failprnt
	cmp byte [0x2002], 'r'
        jne failprnt
        cmp byte [0x2003], 0
        jne failprnt
        jmp clrprnt

clrprnt:
        mov ah, 0x00
        mov al, 0x03
        int 0x10
        jmp promptstart

rbcmd:
	cmp byte [0x2000], 'r'
	jne mfordcmd
	cmp byte [0x2001], 'b'
	jne failprnt
	cmp byte [0x2002], 0
	jne failprnt
        mov ah, 0x00
        mov al, 0x03
        int 0x10
	jmp reboot

reboot:
	int 0x19

nameask:
	mov di, 0x3000
	mov si, nameaskmsg
        call printstr

.loop:
        mov ah, 0x00
        int 0x16
        cmp al, 0x0D
        je .userok
        cmp ah, 0x1C
        je .userok
	cmp al, 0x08
	je backspace
	cmp ah, 0x0E
	je backspace
        mov ah, 0x0E
        int 0x10
        mov [di], al
        inc di
        jmp .loop

.userok:
	mov byte [di], 0
	call newline
	jmp promptstart

promptstart:
        mov di, 0x2000
	mov si, 0x3000
	call printstr
	mov si, prompt
	call printstr
	jmp input

mfordprnt:
        call newline
        mov si, mford
        call printstr
        call newline
        jmp promptstart

mfordcmd:
        cmp byte [0x2000], 'm'
        jne failprnt
        cmp byte [0x2001], '4'
        jne failprnt
        cmp byte [0x2002], 'd'
        jne failprnt
	cmp byte [0x2003], 0
	jne failprnt
        jmp mfordprnt

nameaskmsg:     db "Enter username:", 0
prompt:   db "@kernel: ", 0
version:  db "ATLAS KERNEL v0.04-build1", 0x0A, 0x0D, 0
fail:     db "Command Not Found(write hlp for help)", 0x0A, 0x0D, 0
help:     db "ver, hlp, clr, rb", 0x0A, 0x0D, 0
atcltover:     db "ATCLTO(atlas command line tools) 0.1", 0x0A, 0x0D, 0
initmsg:     db "Kernel OK!", 0x0A, 0x0D, 0
mford:     db "hello developer, thx for using atlas kernel!", 0x0A, 0x0D, 0
;write m4d for a suprise
