[org 0x7C00]

mov bx, 0x1000
mov ah, 0x02
mov al, 4
mov ch, 0
mov dh, 0
mov cl, 2
mov dl, 0x00
int 0x13
jmp 0x1000

times 510 - ( $ - $$ ) db 0
dw 0xaa55
