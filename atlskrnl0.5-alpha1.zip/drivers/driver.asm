[bits 16]
drvdemo:
	mov si, drvdemoprnt
	push ax
	call newline
	call printstr
	mov si, returnwarn
	call printstr
resetdrv:
        mov ax, 0
        mov ds, ax
        mov es, ax
        mov di, 0x2000
        jmp input
drvdemoprnt:     db "demo driver success", 0x0A, 0x0D, 0
returnwarn:     db "press enter to return", 0x0A, 0x0D, 0
call resetdrv
jmp promptstart
