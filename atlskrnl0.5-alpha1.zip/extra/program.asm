[bits 16]

programstart:
	cli
	xor ax, ax
	mov ds, ax
	mov es, ax
	mov ss, ax
	mov sp, 0x7C00
	sti

	mov ah, 0x0e
	mov al, 'O'
	int 0x10

	mov al, 'K'
	int 0x10
	mov al, 0x0A
	int 0x10
	mov al, 0x0D
	int 0x10
	call newlineprg
	call promptstartprg
	jmp resetprg

promptstartprg:
	mov si, promptprg
	jmp printstrprg
	mov si, helpprg
	call printstrprg

resetprg:
	sti
	mov ax, 0
	mov ds, ax
	mov es, ax
	mov di, 0x2000
	mov cx, 16
	rep stosb
	jmp inputprg

inputprg:
	mov ah, 0x00
	int 0x16

	cmp al, 'q'
	je inputfinishprg

	mov ah, 0x0E
	int 0x10

	mov [di], al
	inc di
	jmp inputprg

inputfinishprg:
    mov byte [di], 0

vercmdprg:
	cmp byte [0x2000], 'v'
	jne democmdprg
	cmp byte [0x2001], 'e'
	jne failprntprg
	cmp byte [0x2002], 'r'
	jne failprntprg
	cmp byte [0x2003], 0
	jne failprntprg
	jmp verprntprg
democmdprg:
        cmp byte [0x2000], 'e'
        jne failprntprg
        cmp byte [0x2001], 'x'
        jne failprntprg
        cmp byte [0x2002], 't'
        jne failprntprg
        cmp byte [0x2003], 0
        jne failprntprg
        jmp promptstart
debug:
	mov ah, 0x00
	int 0x16
	mov ah, 0x0e
	int 0x10
	jmp inputprg

printstrprg:
	push ax
textloopprg:
	mov al, [si]
	cmp al, 0
	je printOKprg

	mov ah, 0x0e
	int 0x10
	inc si
	jmp textloopprg

printOKprg:
	pop ax
	ret

verprntprg:
	call newlineprg
	mov si, versionprg
	call printstrprg
	call newlineprg
	jmp promptstartprg

failprntprg:
	call newlineprg
	mov si, failprg
	call printstrprg
	call newlineprg
	mov si, helpprg
	call printstrprg
	call newlineprg
	jmp promptstartprg

newlineprg:
	push ax
	mov ah, 0x0E
        mov al, 0x0A
        int 0x10
	mov al, 0x0D
	int 0x10
	pop ax
	ret
promptprg:   db "(q=ent)kerneluser: ", 0
versionprg:  db "ATLAS KERNEL v0.02", 0x0A, 0x0D, 0
helpprg:     db "Commands: ext, ver", 0x0A, 0x0D, 0
failprg:     db "error", 0x0A, 0x0D, 0

